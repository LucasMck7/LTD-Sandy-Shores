<?php
// ============================================================
//  config.php — LTD Sandy Shores
//  CONFIGURÉ AUTOMATIQUEMENT
// ============================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'u524909271_LTD_SS');
define('DB_USER', 'u524909271_LucasLM');
define('DB_PASS', 'Lucas0108200777390!');
define('API_SECRET', 'LTDSandyShores2025xK9pZm3qR77');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]
        );
    }
    return $pdo;
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-API-Secret');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function checkSecret() {
    $s = $_SERVER['HTTP_X_API_SECRET'] ?? ($_GET['secret'] ?? '');
    if ($s !== API_SECRET) jsonResponse(['error' => 'Non autorisé'], 403);
}
